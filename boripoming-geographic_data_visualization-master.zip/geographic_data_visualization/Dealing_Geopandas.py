import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd


shp_path = r'D:\Program\轨迹数据挖掘\TowardsDataScience\Data\District_boundary\District_Boundary.shp'
map_df = gpd.read_file(shp_path)
df = map_df[['DIST_NAME', 'POPULATION']]
data_for_map = df.rename(index=str, columns={'DIST_NAME': 'DISTRICT',
                                             'POPULATION': 'PUP'})
merged = map_df.set_index('DIST_NAME').join(data_for_map.set_index('DISTRICT'))

variable = 'PUP'
vmin, vmax = 120, 220
fig, ax = plt.subplots(1, figsize=(10,6))
merged.plot(column=variable, cmap='BuGn', linewidth=0.8, ax=ax, edgecolor='0.8')
ax.axis('off')
ax.set_title('Population of Rajasthan', fontdict={'fontsize': '25',
                                                  'fontweight': '3'})
ax.annotate('Source: Rajasthan Datastore, 2019', xy=(0., 0.08),
            xycoords='figure fraction', horizontalalignment='left',
            verticalalignment='top', fontsize=12, color='#555555')
sm = plt.cm.ScalarMappable(cmap='BuGn', norm=plt.Normalize(vmin=vmin,
                                                           vmax=vmax))
sm._A = []
cbar = fig.colorbar(sm)
plt.savefig('4.png')
